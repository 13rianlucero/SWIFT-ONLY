//
//  ViewController.swift
//  gameteast
//
//  Created by CSUFTitan on 10/31/20.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    var coin = 100
    var bet = "None yet"
    var placeToBet = -1
    @IBOutlet weak var coinLabel: UILabel!
    @IBOutlet weak var betLabel: UILabel!
    @IBOutlet weak var results: UILabel!
    @IBOutlet weak var betPicker: UIPickerView!
    @IBOutlet weak var desiredBet: UITextField!
    @IBOutlet weak var desiredLocation: UITextField!
    
    
    
    var bets:[String] = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        coinLabel.text = "Coins: \(coin)"
        betLabel.text = "Bet: \(bet)"
        
        bets = ["Straight"]
        self.betPicker.delegate = self
        self.betPicker.dataSource = self
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return bets.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        bet = bets[row]
        return bet
    }

    @IBAction func runBet(_ sender: UIButton) {
        betLabel.text = "Bet: \(bet)"
        let betText = desiredBet.text!
        let betLoc = desiredLocation.text!
        if bet == "Straight" && coin >= Int(betText) ?? 1 && (Int(betLoc) ?? 1 >= 1 && Int(betLoc) ?? 1 <= 36){
            if Int(betLoc) == Int.random(in: 1..<3) {
                self.coin += (Int(betText) ?? 5 * 35)
                results.text = "Congrats, You won!!!"
            } else {
                results.text = "Too bad, try again"
                self.coin -= (Int(betText) ?? 5 * 35)
            }
        } else
        {
            results.text = "Incorect Input"
        }
        coinLabel.text = "Coins: \(coin)"
    }
    
}

